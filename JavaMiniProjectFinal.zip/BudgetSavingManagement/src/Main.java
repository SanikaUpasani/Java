import authentication.Login;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login obj=new Login();
		obj.setVisible(true);

	}

}
